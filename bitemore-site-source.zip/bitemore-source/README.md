# BITE MORE — WEBSITE V2
Built from the research findings. 47 pages, crawlable, schema on every page.

---

## WHAT CHANGED AND WHY

| Research finding | What this build does about it |
|---|---|
| One page, 353 keywords vs their 9,300 | **47 crawlable pages** — 14 dish pages, 22 neighbourhood pages, 2 location pages, plus core |
| Site returns HTTP 403 to crawlers → 0 LLM mentions | `robots.txt` explicitly allows GPTBot, ClaudeBot, PerplexityBot, OAI-SearchBot, Google-Extended |
| No structured data | JSON-LD on every page: Restaurant, Menu, FAQPage, WebPage, AggregateRating |
| Site claimed 4.5 / 862 | Corrected to **4.3 / 1,000+** everywhere |
| Same review printed 3× | Removed. No testimonials until you have real, varied ones |
| Site never said halal or Italian-American | Both are in the H1, the title tags and the trust trio |
| Cajun Alfredo hero at 73% vs Oklahoma Onion at 82% | **Oklahoma Onion Smash is now the hero image and lead item** |
| "Generous portions" vs portion complaints | That claim is **gone**. Replaced with cooked-to-order, protein counts and open pricing |
| No prices anywhere | **Every price is on the menu page** — transparency answers the value objection |
| Protein counts buried in UberEats descriptions | Surfaced everywhere, plus a dedicated `/tags/high-protein.html` page |
| Wings at 59–64% | Still on the menu, no longer featured in the hero |
| "SIGNTAURE", "Specilaty" typos | Fixed |
| Franchise CTA → cloudways staging URL | Real franchise page with an application form |
| No catering, careers, team, gift card pages | All built |
| Competitor's meta description sells direct ordering | "Why order direct" section on the home page + direct-price framing on the menu |
| No Meta Pixel | Pixel block is in every `<head>`, commented out, needs your ID |

---

## THE PAGE MAP

```
index.html                    home
menu.html                     full menu with prices and protein counts
locations.html                both kitchens
buckhead.html  duluth.html    location landing pages
catering.html                 packages + quote form
franchise.html                opportunity + application
about.html  team.html  careers.html  gift-cards.html

tags/            14 dish pages — the keyword engine
  halal-burgers · oklahoma-onion-smash · smash-burger · cajun-alfredo
  alfredo-pasta · halal-pasta · chicken-wings · loaded-fries
  mac-and-cheese · nashville-hot-chicken · chicken-tenders · birria
  high-protein · late-night-food

places/          22 neighbourhood pages — the local SEO engine
  Buckhead side: buckhead, garden-hills, peachtree-park, peachtree-hills,
  pine-hills, lindbergh-morosgo, south-tuxedo-park, brookhaven,
  sandy-springs, vinings, midtown-atlanta, morningside-lenox-park,
  smyrna, marietta
  Duluth side: duluth, johns-creek, suwanee, berkeley-lake, norcross,
  peachtree-corners, sugar-hill, dunwoody

sitemap.xml      all 47 URLs
robots.txt       allows AI crawlers explicitly
```

Every page links to every dish page and every neighbourhood page through the
footer and the "known for / areas we serve" blocks. That internal linking is what
makes 47 pages rank instead of 47 pages sitting there.

---

## BEFORE THIS GOES LIVE — REQUIRED

**1. Hours.** Everything uses one config block at the top of the builder:
closed Monday, Tue–Wed 11am–10pm, Thu–Sun 11am–midnight. Your platforms currently
disagree — DoorDash says 11am–12:40am, UberEats shows you open Monday and until
2:55am, Yelp says until 3am Friday and Saturday. **Decide the real hours, then set
them identically here, on DoorDash, UberEats, Grubhub, Google Business Profile and
Yelp.** Wrong hours on a location page is worse than no location page.

**2. Prices.** The menu shows the prices currently listed on the delivery apps.
The whole "order direct" argument only works if **your direct prices are lower
than the app prices.** Set direct prices first, then update `MENU` in the builder.
Also fix the Cajun Alfredo inconsistency — it's $19.99 on DoorDash and $21.99 on
UberEats right now.

**3. Meta Pixel.** Every page has the Pixel block commented out in `<head>`.
Replace `PIXEL_ID` and uncomment. Without this there is no ad campaign.

**4. Hosting.** This must go somewhere that isn't DoorDash's storefront platform
and that returns 200 to crawlers. Verify with Google Search Console's URL
Inspection tool after launch — if it still 403s, nothing else here matters.

**5. Email addresses.** `catering@bitemore.us`, `franchise@bitemore.us`,
`careers@bitemore.us` are referenced and need to exist.

**6. The team page is a placeholder.** Real names, photos and one-line bios, or
remove it from the nav. Empty is worse than absent.

**7. Submit the sitemap** to Google Search Console and Bing Webmaster Tools.

---

## KNOWN GAPS I DIDN'T FILL

- **No testimonials anywhere.** You only have one usable public review and it was
  printed three times on the old site. Pull five real ones with names and dates,
  then I'll build a reviews section with Review schema.
- **Photography.** Still using the DoorDash CDN images. Given the "photo was
  misleading for the portion" complaints, new photos shot at true portion size are
  a priority — and they'd fix the objection at its source.
- **Pizza isn't on the menu.** Your bag artwork lists it. Either it launches or it
  comes off the bag.
- **Ordering is still `order.online`.** Every Order button points there. Moving to
  a platform where you own the customer, the loyalty programme and the gift cards
  is the next decision after hosting.

---

## HOW TO EDIT

The site is generated. Source scripts: `v2_base.py` (config, menu data, shared
components) and `v2_build.py` (pages). Change the `MENU`, `HOURS_HUMAN`,
`TAGS` or `PLACES` lists and rebuild — every page updates, including the sitemap.

Editing the HTML directly works too, but you'll be editing 47 files by hand the
next time a price changes.
